import altair as alt
import matplotlib.pyplot as plt
alt.data_transformers.enable('default', max_rows=None)
import pandas as pd
from flask import Flask, render_template, jsonify, request
app = Flask(__name__, static_folder='public')
import json
import random

@app.route("/")
def index():
    return render_template("index.html", title="广东省城市综合分析报告")

@app.route("/data")
def data():
    return render_template("sub.html", title="广东省城市综合分析报告")

@app.route("/price")
def price():
    df = df_price

    df.rename(columns={'city':'城市', 'house_price':'房价','wage':'工资','rate':'房价收入比'}, inplace = True) #将字段改为中文

    all_city = df.城市.values #包含所有城市的数组

    cities = request.args.getlist("cities[]") #在这里选择要对比的城市,所有城市一起显示则用all_city
    
    df_alt = df[df.城市.isin(cities)]

    nearest = alt.selection(type='single', nearest=True, on='mouseover', fields=['x'], empty='none')

    #房价收入比柱状图
    rate = alt.Chart(df_alt,width = 600).mark_bar().encode(
        alt.Y("城市", title="", sort=alt.EncodingSortField(field="房价收入比")),
        alt.X("房价收入比", title="房价收入比（%） 注：房价收入比越低，越容易买房"),
        tooltip=['城市','房价收入比']
    )

    df2 = df_alt.melt(id_vars=['城市'], value_vars=['工资', '房价']) #分解dataframe以便生成组合柱状图

    #房价与收入组合柱状图
    price = alt.Chart(df2).mark_bar().encode(
        alt.X('variable',title = ""),
        alt.Y('value', title='工资(元), 房价(元/㎡)'),
        color=alt.Color('variable'),
        column='城市',
        tooltip=['variable','value']
    )

    rate_json = json.loads(rate.to_json())
    price_json = json.loads(price.to_json())
    
    return jsonify({
        "rate": rate_json,
        "price": price_json,
        "all": [t for t in df.城市.unique()]
    })

@app.route("/weather")
def weather():
    df = df_weather

    cities = request.args.getlist("cities[]")
    city = request.args.get("city") #在这里选择柱状图2要单独显示的城市
    season = request.args.get("season") #在这里选择柱状图1，柱状图3，柱状图4的季节
    weather = request.args.get("weather") #选择柱状图1，柱状图2要突出显示的天气

    length = len(cities)

    df2 = df[df.城市.isin(cities)].query(f"季节 == '{season}'")

    #显示所选城市(cities)某个天气(weather)在某个季节(season)出现频率的柱状图 #柱状图1

    bar = alt.Chart(df2,width=600).mark_bar().encode(
        alt.Y('城市',title = "",sort=alt.EncodingSortField(field=weather)),
        alt.X(weather, title=season+ "季" + weather + '频率',scale=alt.Scale(domain=[0, 20])),
        tooltip=['城市',weather,'季节']
    )

    #某城市(city)的某天气(weather)在四季中的出现频率柱状图 #柱状图2

    bar2 = alt.Chart(df.query(f"城市 == '{city}'"),width=600).mark_bar().encode(
        alt.X(weather, title=city + "四季" + weather + '频率'),
        alt.Y('季节',title = "",sort=alt.EncodingSortField(field=weather)),
        tooltip=['城市',weather,'季节']
    )

    df3 = df.melt(id_vars=['城市','季节'], value_vars=['晴天', '雨天','阴天','雪天'])
    df3 = df3[df3.城市.isin(cities)]

    #显示所选城市(cities)的所有天气在某个季节(season)出现频率的组合柱状图 #柱状图3
    bar3 = alt.Chart(df3).mark_bar().encode(
        alt.X('variable',title = ""),
        alt.Y('value', title=''),
        color=alt.Color('variable'),
        column='城市',
        tooltip=['城市','季节','variable','value']
    )

    df_alt=df3.query(f"季节 == '{season}'")
    value = df_alt.groupby(['城市','variable']).sum().value
    value2 = df_alt.query(f"季节 == '{season}'").groupby(['城市','variable']).sum().groupby(['城市']).sum().value
    ratio = value/value2 *100
    df_alt = pd.merge(df_alt,ratio.reset_index(name='ratio'),how='left')
    df_alt.ratio = df_alt.ratio.apply(lambda x: float(format(x, '.1f')))

    #显示所选城市(cities)的所有天气在某个季节(season)分布情况的柱状图 #柱状图4
    bar4 = alt.Chart(df_alt,width=600).mark_bar().encode(
        alt.X('sum(ratio)', stack='zero'),
        alt.Y('城市',title = '城市'),
        color = 'variable',
        tooltip=['城市','季节','variable','ratio']
    ) + alt.Chart(df_alt,width=600).mark_text(dx=-10, dy=3, color='white').encode(
        alt.X('sum(ratio)',title = f'各市{season}季天气分布 (%)', stack='zero'),
        alt.Y('城市',title = '城市'),
        detail='variable',
        text=alt.Text('sum(ratio)')
    )


    bar_json = json.loads(bar.to_json())
    bar2_json = json.loads(bar2.to_json())
    bar3_json = json.loads(bar3.to_json())
    bar4_json = json.loads(bar4.to_json())

    return jsonify({
        "bar": bar_json,
        "bar2": bar2_json,
        "bar3": bar3_json,
        "bar4": bar4_json,
        "all": [t for t in df.城市.unique()]
    })

@app.route("/industry")
def industry():
    df = df_gdp
    all_city = df.城市.values #包含所有城市的数组，可以放在下面的cities里

    cities = request.args.getlist("cities[]") #选择柱状图1和柱状图2的城市
    city = request.args.get("city") #选择条形图2的城市
    year = request.args.get("year") #选择柱状图1和柱状图2的年份,范围1990-2018
    indus = request.args.get("industry") # ["第一产业","第二产业","第三产业"][0] #通过改变index来选择条形图1显示的产业
    year_min = request.args.get("year_min") #开始年份
    year_max = request.args.get("year_max") #结束年份

    df_alt = df[df.城市.isin(cities)]

    df2 = df_alt.melt(id_vars=['城市','年份'], value_vars=['第一产业', '第二产业','第三产业'])
    df2.rename(columns = {'城市':'城市','年份':"年份",'variable':'产业','value':'数值'},inplace=True)


    #显示所选各城市(cities)各产业在某一年(year)的发展情况的组合柱状图 #柱状图1
    bar = alt.Chart(df2.query(f"年份=='{year}'")).mark_bar().encode(
        alt.X('产业',title = "" ),
        alt.Y('数值', title=f"{year}年广东省各市产业情况（亿元）"),
        color=alt.Color('产业'),
        tooltip=['城市','产业','数值'],
        column='城市'
    )

    #显示所选城市(city)的某一年(year)的产业分布情况 #柱状图2
    value = df2.groupby(['城市','产业']).sum().数值
    value2 = df2.groupby(['城市','产业']).sum().groupby(['城市']).sum().数值
    ratio = value/value2 *100
    df2 = pd.merge(df2,ratio.reset_index(name='ratio'),how='left')
    df2.ratio = df2.ratio.apply(lambda x: float(format(x, '.1f')))
    df2.rename(columns = {'城市':'城市','年份':"年份",'variable':'产业','value':'数值','ratio':"占比"},inplace=True)

    bar2 = alt.Chart(df2.query(f'年份=={year}'),width=900).mark_bar().encode(
        alt.X('sum(占比)', stack='zero',scale=alt.Scale(domain=[0, 100])),
        alt.Y('城市',title = '城市'),
        color = '产业',
        tooltip=['城市','年份','产业','占比'],
        order=alt.Order('产业')
    ) + alt.Chart(df2.query(f'年份=={year}'),width=900).mark_text(color='white',
    baseline="middle",dx=-15, dy=3).encode(
        alt.X('sum(占比)',title = f'各城市{year}年产业分布（%）', stack='zero'),
        alt.Y('城市'),
        detail='产业',
        text=alt.Text('sum(占比)'),
        order=alt.Order('产业')
    )

    #显示所选各城市(cities)的某一产业(indus)历年发展趋势 #条形图1
    line = alt.Chart(df_alt.query(f"年份>={year_min} and 年份<={year_max}"),width = 600).mark_line().encode(
        alt.X('年份',title = f"各市{indus}发展趋势"),
        alt.Y(indus,title = "单位：亿元"),
        color = "城市"
    )+ alt.Chart(df_alt.query(f"年份>={year_min} and 年份<={year_max}"),width = 600).mark_point(size=5).encode(
        alt.X('年份',title = f"各市{indus}发展趋势"),
        alt.Y(indus,title = "单位：亿元"),
        tooltip = ['城市','年份',indus],
        color = "城市"
    ).interactive()

    #显示所选城市(city)的各产业历年发展趋势 #条形图2
    line2 = alt.Chart(df2.query(f"城市 == '{city}' and 年份>={year_min} and 年份<={year_max}"),width = 600).mark_line().encode(
        alt.X('年份',title = f"{city}各产业发展趋势"),
        alt.Y('数值',title = "单位：亿元"),
        color = "产业"
    ) + alt.Chart(df2.query(f"城市 == '{city}' and 年份>={year_min} and 年份<={year_max}"),width = 600).mark_point(size = 5).encode(
        alt.X('年份',title = f"{city}各产业发展趋势"),
        alt.Y('数值',title = "单位：亿元"),
        tooltip = ['城市','年份','产业','数值'],
        color = "产业"
    ).interactive()

    bar_json = json.loads(bar.to_json())
    bar2_json = json.loads(bar2.to_json())
    line_json = json.loads(line.to_json())
    line2_json = json.loads(line2.to_json())

    return jsonify({
        "bar": bar_json,
        "bar2": bar2_json,
        "line": line_json,
        "line2": line2_json,
        "all": [t for t in df.城市.unique()]
    })

@app.route("/gdp")
def gdp():
    df = df_gdp
    cities = request.args.getlist("cities[]") #在此选择城市
    year_min = request.args.get("year_min") #开始年份
    year_max = request.args.get("year_max") #结束年份

    #各市GDP历年发展趋势图
    line = alt.Chart(df.query(f"城市 in {cities} and 年份>={year_min} and 年份<={year_max}").dropna(),width = 800).mark_line(size=2,point=True).encode(
        alt.X("年份",title="各市GDP历年发展趋势"),
        alt.Y("GDP",title = 'GDP（亿元）'),
        tooltip=["城市","年份","GDP"],
        color='城市'
    ).interactive() 

    #各市人均GDP历年发展趋势图
    line2 = alt.Chart(df.query(f"城市 in {cities} and 年份>={year_min} and 年份<={year_max}").dropna(),width = 800).mark_line(size=2,point=True).encode(
        alt.X("年份",title="各市人均GDP历年发展趋势"),
        alt.Y("人均GDP",title = '人均GDP（元/人）'),
        tooltip=["城市","年份","人均GDP"],
        color='城市'
    ).interactive()

    line_json = json.loads(line.to_json())
    line2_json = json.loads(line2.to_json())

    return jsonify({
        "line": line_json,
        "line2": line2_json,
        "all": [t for t in df.城市.unique()]
    })

@app.route("/population")
def population():
    df = df_gdp
    df2 = df.dropna()

    cities = request.args.getlist("cities[]") #在此选择城市
    city = request.args.get("city")
    year_min = request.args.get("year_min") #开始年份
    year_max = request.args.get("year_max") #结束年份
    pop = request.args.get("type") #改变后面的index来选择要对比的人口类型

    #各市（cities）各人口类型（pop）发展趋势条形图 #可以选择是要对比年末总人口，常住人口还是户籍人口
    line = alt.Chart(df2.query(f"城市 in {cities} and 年份>={year_min} and 年份<={year_max}"),width = 800).mark_line(point=True).encode(
        alt.X("年份",title = f"各市{pop}历年发展趋势"),
        alt.Y(f'{pop}',title = f'{pop}（万人）'),
        color="城市",
        tooltip=["城市","年份",f'{pop}']
    ).interactive()

    df3 = df2.melt(id_vars=["城市","年份"],value_vars=["常住人口","户籍人口"])


    #某市（city）常住人口与户籍人口历年发展情况关系条形图  #这里没有放入年末总人口，因为年末总人口的数据几乎与户籍人口重合
    bar = alt.Chart(df3.query(f"城市 == '{city}' and 年份>={year_min} and 年份<={year_max}"),width = 700).mark_bar(width = 20,opacity=0.9).encode(
        alt.X('年份',title = f"{city}历年人口发展趋势"),
        alt.Y('value',title="数量（万人）"),
        color = 'variable'
    )+ alt.Chart(df3.query(f"城市 == '{city}' and 年份>={year_min} and 年份<={year_max}")).mark_text(size = 12,dx=0,dy=-8).encode(
        alt.X('年份',title = ""),
        alt.Y('value',title="数量（万人）"),
        detail = "variable",
        text = alt.Text("value")
    )+ alt.Chart(df3.query(f"城市 == '{city}' and 年份>={year_min} and 年份<={year_max}")).mark_line(opacity=0.5).encode(
        alt.X('年份',title = ""),
        alt.Y('value',title="数量（万人）"),
        color = 'variable'
    )

    line_json = json.loads(line.to_json())
    bar_json = json.loads(bar.to_json())

    return jsonify({
        "line": line_json,
        "bar": bar_json,
        "all": [t for t in df.城市.unique()]
    })

if __name__ == "__main__":
    df_price = pd.read_excel("wage_price.xlsx")
    df_weather = pd.read_excel("weather.xlsx")
    df_gdp = pd.read_excel("GDP.xlsx",thousands=",")
    app.run(debug=True)